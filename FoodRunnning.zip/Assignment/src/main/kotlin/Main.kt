import java.util.*

// Data class to represent coffee preferences
data class Coffee(val type: String, val sugar: Int)

class Robot(private val name: String) {

    // Function to ring the alarm at a specified time
    fun ringAlarm(time: String, daysToSkip: List<String>) {
        val today = Calendar.getInstance()
        val dayOfWeek = today.get(Calendar.DAY_OF_WEEK)
        val todayName = when (dayOfWeek) {
            Calendar.SUNDAY -> "Sunday"
            Calendar.MONDAY -> "Monday"
            Calendar.TUESDAY -> "Tuesday"
            Calendar.WEDNESDAY -> "Wednesday"
            Calendar.THURSDAY -> "Thursday"
            Calendar.FRIDAY -> "Friday"
            Calendar.SATURDAY -> "Saturday"
            else -> ""
        }

        if (!daysToSkip.contains(todayName)) {
            println("$name is ringing the alarm at $time on $todayName.")
        }
    }

    // Function to make coffee with custom preferences
    fun makeCoffee(type: String, sugar: Int) {
        println("$name is making $type coffee with $sugar sugar.")
    }

    // Function to heat water to a specified temperature
    fun heatWater(temperature: Int, willBathe: Boolean) {
        val bathStatus = if (willBathe) "will" else "won't"
        println("$name is heating water to $temperature°C. $name $bathStatus take a bath today.")
    }

    // Function to pack your bag based on timetable
    fun packBag(timetable: Map<String, List<String>>) {
        val today = Calendar.getInstance()
        val dayOfWeek = today.get(Calendar.DAY_OF_WEEK)
        val todayName = when (dayOfWeek) {
            Calendar.SUNDAY -> "Sunday"
            Calendar.MONDAY -> "Monday"
            Calendar.TUESDAY -> "Tuesday"
            Calendar.WEDNESDAY -> "Wednesday"
            Calendar.THURSDAY -> "Thursday"
            Calendar.FRIDAY -> "Friday"
            Calendar.SATURDAY -> "Saturday"
            else -> ""
        }

        val subjects = timetable[todayName] ?: emptyList()
        println("$name is packing the bag for $todayName with books: $subjects")
    }

    // Function to cook breakfast and lunch
    fun cookMeals(breakfastOptions: List<String>, lunchOptions: List<String>) {
        val breakfast = breakfastOptions.random()
        val lunch = lunchOptions.random()
        println("$name is cooking $breakfast for breakfast and $lunch for lunch.")
    }

    // Function to iron clothes
    fun ironClothes(outfit: String) {
        println("$name is ironing $outfit for you.")
    }
}

fun main() {
    // Create a Robot instance with a name
    val myRobot = Robot("MorningHelper")

    // Set alarm preferences
    val alarmTime = "7:00 AM"
    val daysToSkipAlarm = listOf("Saturday", "Sunday")

    // Set coffee preferences
    val coffeeType = "Black"
    val sugarAmount = 2

    // Set bathing preferences
    val waterTemperature = 40 // in Celsius
    val willBatheToday = true

    // Set timetable
    val timetable = mapOf(
        "Monday" to listOf("Math", "Physics"),
        "Tuesday" to listOf("History", "English"),
        "Wednesday" to listOf("Chemistry", "Biology"),
        "Thursday" to listOf("Geography", "Music"),
        "Friday" to listOf("Computer Science", "Physical Education")
    )

    // Set meal options
    val breakfastOptions = listOf("Oatmeal", "Eggs", "Toast")
    val lunchOptions = listOf("Salad", "Sandwich", "Pasta")

    // Set outfit for the day
    val outfit = "Formal shirt and trousers"

    // Call Robot functions to perform tasks
    myRobot.ringAlarm(alarmTime, daysToSkipAlarm)
    myRobot.makeCoffee(coffeeType, sugarAmount)
    myRobot.heatWater(waterTemperature, willBatheToday)
    myRobot.packBag(timetable)
    myRobot.cookMeals(breakfastOptions, lunchOptions)
    myRobot.ironClothes(outfit)
}
